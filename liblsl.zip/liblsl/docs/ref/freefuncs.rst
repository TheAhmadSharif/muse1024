LSL freestanding functions
==========================

.. doxygenfunction:: lsl_local_clock

Here we talk about `lsl_time_correction_ex`:

.. doxygenfunction:: lsl_time_correction_ex()

And here we list some other functions:

.. doxygenfunction:: lsl_library_version()
.. doxygenfunction:: lsl_library_info()
.. doxygenfunction:: lsl_protocol_version()

