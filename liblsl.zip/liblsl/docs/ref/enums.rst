Enumerations / Flags
====================

Postprocessing options:

.. doxygenenum:: lsl_processing_options_t

Channel formats:

.. doxygenenum:: lsl_channel_format_t

Error codes:

.. doxygenenum:: lsl_error_code_t